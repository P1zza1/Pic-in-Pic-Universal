chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      function pickVideo() {
        // Pega o vídeo que estiver tocando/visível; se não achar, pega o maior <video> na página
        const videos = Array.from(document.querySelectorAll('video'));
        if (videos.length === 0) return null;

        const playing = videos.find(v => !v.paused && v.readyState > 0);
        if (playing) return playing;

        // fallback: maior vídeo em área visível
        return videos.reduce((best, v) => {
          const area = v.clientWidth * v.clientHeight;
          const bestArea = best ? best.clientWidth * best.clientHeight : -1;
          return area > bestArea ? v : best;
        }, null);
      }

      function activatePiP(video) {
        video.disablePictureInPicture = false;
        return video.requestPictureInPicture();
      }

      function waitForMetadata(video, timeoutMs = 8000) {
        return new Promise((resolve, reject) => {
          // readyState >= 1 (HAVE_METADATA) já é suficiente
          if (video.readyState >= 1) {
            resolve(video);
            return;
          }

          const onLoaded = () => {
            cleanup();
            resolve(video);
          };
          const onError = () => {
            cleanup();
            reject(new Error('Falha ao carregar o vídeo.'));
          };
          const timer = setTimeout(() => {
            cleanup();
            reject(new Error('Tempo esgotado esperando os metadados do vídeo.'));
          }, timeoutMs);

          function cleanup() {
            clearTimeout(timer);
            video.removeEventListener('loadedmetadata', onLoaded);
            video.removeEventListener('error', onError);
          }

          video.addEventListener('loadedmetadata', onLoaded, { once: true });
          video.addEventListener('error', onError, { once: true });

          // Alguns players (Prime Video, Disney+) só carregam metadata depois de um "play"
          // então tentamos disparar isso sem travar o autoplay do site.
          if (video.paused) {
            video.play().catch(() => {
              // ignora - alguns sites bloqueiam play() fora de gesto do usuário,
              // mas o clique no ícone da extensão já conta como gesto do usuário na maioria dos casos.
            });
          }
        });
      }

      async function run() {
        let video = pickVideo();

        if (!video) {
          alert('Nenhum vídeo encontrado nesta página.');
          return;
        }

        try {
          if (video.readyState < 1) {
            video = await waitForMetadata(video);
          }
          await activatePiP(video);
        } catch (err) {
          // Tenta de novo uma vez, caso o vídeo certo tenha mudado durante a espera
          try {
            const retryVideo = pickVideo() || video;
            await activatePiP(retryVideo);
          } catch (err2) {
            alert('Não foi possível ativar o Picture-in-Picture: ' + err2.message);
          }
        }
      }

      run();
    }
  });
});
