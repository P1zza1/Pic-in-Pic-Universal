chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      function pickVideo() {
        // Grab the video that's playing/visible; if none, pick the largest <video> on the page
        const videos = Array.from(document.querySelectorAll('video'));
        if (videos.length === 0) return null;

        const playing = videos.find(v => !v.paused && v.readyState > 0);
        if (playing) return playing;

        // fallback: largest visible video
        return videos.reduce((best, v) => {
          const area = v.clientWidth * v.clientHeight;
          const bestArea = best ? best.clientWidth * best.clientHeight : -1;
          return area > bestArea ? v : best;
        }, null);
      }

      function activatePiP(video) {
        video.disablePictureInPicture = false;
        return video.requestPictureInPicture();
      }

      function waitForMetadata(video, timeoutMs = 8000) {
        return new Promise((resolve, reject) => {
          // readyState >= 1 (HAVE_METADATA) is already enough
          if (video.readyState >= 1) {
            resolve(video);
            return;
          }

          const onLoaded = () => {
            cleanup();
            resolve(video);
          };
          const onError = () => {
            cleanup();
            reject(new Error('Failed to load the video.'));
          };
          const timer = setTimeout(() => {
            cleanup();
            reject(new Error('Timed out waiting for the video metadata.'));
          }, timeoutMs);

          function cleanup() {
            clearTimeout(timer);
            video.removeEventListener('loadedmetadata', onLoaded);
            video.removeEventListener('error', onError);
          }

          video.addEventListener('loadedmetadata', onLoaded, { once: true });
          video.addEventListener('error', onError, { once: true });

          // Some players (Prime Video, Disney+) only load metadata after a "play"
          // so we try to trigger that without blocking the site's own autoplay.
          if (video.paused) {
            video.play().catch(() => {
              // ignore - some sites block play() outside a user gesture,
              // but clicking the extension icon already counts as a user gesture in most cases.
            });
          }
        });
      }

      async function run() {
        let video = pickVideo();

        if (!video) {
          alert('No video found on this page.');
          return;
        }

        try {
          if (video.readyState < 1) {
            video = await waitForMetadata(video);
          }
          await activatePiP(video);
        } catch (err) {
          // Try once more, in case the right video changed while we were waiting
          try {
            const retryVideo = pickVideo() || video;
            await activatePiP(retryVideo);
          } catch (err2) {
            alert('Could not enable Picture-in-Picture: ' + err2.message);
          }
        }
      }

      run();
    }
  });
});
